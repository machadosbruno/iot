// Nome do aluno: Bruno Soares Machado
// Prontuário: BA3139786

#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

const char* ssid = "iotads";
const char* password = "";

const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

//const int LED_PIN = 2;
#define DHTPIN 4
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

void setup_wifi() {
  delay(10);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.println("Tentando Conectar Wi Fi");
  }
}
/*
void callback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
}
*/
void reconnect() {
  while (!client.connected()) {
    String clientId = "ESP32Client-Bruno-";
    //clientId += String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      client.subscribe("bruno/umidade");
      client.subscribe("bruno/temperatura");
    } else {
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  dht.begin();

  setup_wifi();
  client.setServer(mqtt_server, 1883);
  //client.setCallback(callback);
}

void loop() {
  
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
  
  float umidade = dht.readHumidity();
  float temperatura = dht.readTemperature(); // Celsius
  delay(2000);
  
  if (isnan(umidade) || isnan(temperatura)) {
    Serial.println("Erro ao ler o DHT22!");
    return;
  }

  // Exibe no Serial Monitor
  Serial.print("Temperatura: ");
  Serial.print(temperatura);
  Serial.println(" °C");

  Serial.print("Umidade: ");
  Serial.print(umidade);
  Serial.println(" %");

  // Converte para string para publicar no MQTT
  char tempString[8];
  char humString[8];

  dtostrf(temperatura, 1, 2, tempString);
  dtostrf(umidade, 1, 2, humString);

  // Publica nos tópicos da HiveMQ
  client.publish("brunoEmiguel/temperatura", tempString);
  client.publish("brunoEmiguel/umidade", humString);

  Serial.println("Dados enviados ao broker MQTT.");
  Serial.println("-----------------------------");
}